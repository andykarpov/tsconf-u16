USBHost HID Class Sample  Readme
---------------------------------

This demo will read in data from interrupt endpoint on a HID class devices and output the received data to the UART interface. It will not check the device type connected although this can be changed to check for specific HID class devices.

It has been tested with various keyboard.

Retrictions:
- Reports are assumed to be 8 bytes.

Known bugs:
- N/A

Features requests:
- N/A
